package Ariketa1;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import Ariketa1.*;
import Ariketa1.Ariketa7;

public class Ariketa7Añadir extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox comboBoxMes;
	private JComboBox comboBoxDia;
	private JComboBox comboBoxHora;
	private JComboBox comboBoxMins;
	private JTextField textFieldDe;
	private JTextField textFieldPara;
	private JTextField textFieldMensaje;
	public String hila;
	public String egu;
	public String ordu;
	public String mins;
	public String data;
	public String dataE;
	public String noren;
	public String norentzat;
	public String mensaje;
	
	

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Ariketa7Añadir() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblFecha = new JLabel("Data:");
		lblFecha.setBounds(10, 11, 46, 14);
		contentPane.add(lblFecha);

		comboBoxMes = new JComboBox();
		comboBoxMes.setModel(new DefaultComboBoxModel(new String[] { "Urtarrila", "otsaila", "martxoa", "apirila", "maiatza",
				"Ekaina", "Uztaila", "Abuztua", "Iraila", "Urria", "Azaroa", "Abendua" }));
		comboBoxMes.setBounds(112, 7, 120, 22);
		contentPane.add(comboBoxMes);

		comboBoxDia = new JComboBox();
		comboBoxDia.setModel(new DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08",
				"09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25",
				"26", "27", "28", "29", "30", "31" }));
		comboBoxDia.setBounds(292, 7, 46, 22);
		contentPane.add(comboBoxDia);

		JLabel lblHora = new JLabel("Hora:");
		lblHora.setBounds(10, 62, 46, 14);
		contentPane.add(lblHora);

		comboBoxHora = new JComboBox();
		comboBoxHora.setModel(new DefaultComboBoxModel(new String[] { "00", "01", "02", "03", "04", "05", "06", "07",
				"08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" }));
		comboBoxHora.setBounds(112, 58, 52, 22);
		contentPane.add(comboBoxHora);

		comboBoxMins = new JComboBox();
		comboBoxMins.setModel(new DefaultComboBoxModel(
				new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
						"15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
						"31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46",
						"47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60" }));
		comboBoxMins.setBounds(180, 58, 52, 22);
		contentPane.add(comboBoxMins);

		JLabel lblHoraa = new JLabel(":");
		lblHoraa.setHorizontalAlignment(SwingConstants.CENTER);
		lblHoraa.setBounds(149, 62, 46, 14);
		contentPane.add(lblHoraa);

		JLabel lblDe = new JLabel("Norena:");
		lblDe.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDe.setBounds(10, 114, 92, 14);
		contentPane.add(lblDe);

		JLabel lblPara = new JLabel("Norentzat:");
		lblPara.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPara.setBounds(10, 139, 92, 14);
		contentPane.add(lblPara);

		JLabel lblMenjase = new JLabel("Mezua:");
		lblMenjase.setHorizontalAlignment(SwingConstants.RIGHT);
		lblMenjase.setBounds(10, 164, 92, 14);
		contentPane.add(lblMenjase);

		textFieldDe = new JTextField();
		textFieldDe.setBounds(112, 111, 312, 20);
		contentPane.add(textFieldDe);
		textFieldDe.setColumns(10);

		textFieldPara = new JTextField();
		textFieldPara.setColumns(10);
		textFieldPara.setBounds(112, 136, 312, 20);
		contentPane.add(textFieldPara);

		textFieldMensaje = new JTextField();
		textFieldMensaje.setColumns(10);
		textFieldMensaje.setBounds(112, 161, 312, 89);
		contentPane.add(textFieldMensaje);

		JButton btnCancel = new JButton("Utzi");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Ariketa7 frame = new Ariketa7();
					frame.setVisible(true);
				} catch (Exception i) {
					i.printStackTrace();
				}
				dispose();
			}
		});
		btnCancel.setBounds(10, 227, 92, 23);
		contentPane.add(btnCancel);

		JButton btnEnviar = new JButton("Bidali");
		btnEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				hila = (String) comboBoxMes.getSelectedItem();
				egu = (String) comboBoxDia.getSelectedItem();
				ordu = (String) comboBoxHora.getSelectedItem();
				mins = (String) comboBoxMins.getSelectedItem();
				data = egu + " " + hila;
				dataE = ordu + ":" + mins;
				noren = textFieldDe.getText();
				norentzat = textFieldPara.getText();
				mensaje = textFieldMensaje.getText();
				Mezua mezua = new Mezua(data, dataE, noren, norentzat, mensaje);
				System.out.println(mezua.toString());
				Ariketa7.mezuak.add(mezua);
				añadirMezuak();
				try {
					Ariketa7 frame = new Ariketa7();
					frame.setVisible(true);
				} catch (Exception i) {
					i.printStackTrace();
				}
				dispose();
			}
		});
		btnEnviar.setBounds(10, 194, 92, 23);
		contentPane.add(btnEnviar);
	}
	
	public void añadirMezuak() {
		
		
	}


}
