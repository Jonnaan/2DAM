package Ariketa1;

public class Mezua {

	String fecha;
	String hora;
	String de;
	String para;
	String mexua;

	public Mezua(String fecha, String hora, String de, String para, String mexua) {
		this.fecha = fecha;
		this.hora = hora;
		this.de = de;
		this.para = para;
		this.mexua = mexua;
	}

	public Mezua() {
	}

	public String getFecha() {
		return fecha;
	}

	public String getHora() {
		return hora;
	}

	public String getDe() {
		return de;
	}

	public String getPara() {
		return para;
	}

	public String getMexua() {
		return mexua;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public void setDe(String de) {
		this.de = de;
	}

	public void setPara(String para) {
		this.para = para;
	}

	public void setMexua(String mexua) {
		this.mexua = mexua;
	}

	@Override
	public String toString() {
		return fecha + " -|- " + hora + " -|- " + de + " -|- " + para + " -|- " + mexua;
	}

}
