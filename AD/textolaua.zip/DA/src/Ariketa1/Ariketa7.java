package Ariketa1;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Ariketa7 extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private static BufferedWriter bw;
    public static ArrayList<Mezua> mezuak;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        mezuak = new ArrayList<>();
        EventQueue.invokeLater(() -> {
            try {
                Ariketa7 frame = new Ariketa7();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public Ariketa7() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btnIrten = new JButton("Irten");
        btnIrten.addActionListener(e -> System.exit(0));
        btnIrten.setBounds(335, 227, 89, 23);
        contentPane.add(btnIrten);

        JButton btnCargar = new JButton("Cargar mezuak");
        btnCargar.addActionListener(e -> cargar());
        btnCargar.setBounds(10, 11, 150, 23);
        contentPane.add(btnCargar);

        JButton btnGorde = new JButton("Gorde mezuak");
        btnGorde.addActionListener(e -> gorde());
        btnGorde.setBounds(274, 11, 150, 23);
        contentPane.add(btnGorde);

        JButton btnGehitu = new JButton("Gehitu mezuak");
        btnGehitu.addActionListener(e -> {
        	gehitu();
        	dispose();
        });
        btnGehitu.setBounds(10, 45, 150, 23);
        contentPane.add(btnGehitu);

        JButton btnInprimatu = new JButton("Inprimatu mezuak");
        btnInprimatu.addActionListener(e -> {
            if (mezuak != null) {
                inprimatu();
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Error");
            }
        });
        btnInprimatu.setBounds(274, 45, 150, 23);
        contentPane.add(btnInprimatu);

        sortuFicheroa();
    }

    private static void sortuFicheroa() {
        if (bw == null) {
            try {
                bw = new BufferedWriter(new FileWriter("src/Mezuak.txt", true));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void cargar() {
        try (BufferedReader lector = new BufferedReader(new FileReader("src/Mezuak.txt"))) {
            String linea;
            System.out.println("Memoriako mezuak kargatzen...");

            while ((linea = lector.readLine()) != null) {
            

            	// split() metodoa erabiliz, katea array-an gordeko dugu
                String[] katea = linea.split(" -\\|- "); 

         
             
                for (int i = 0; i < katea.length; i++) {
                    System.out.println("Elemento " + i + ": [" + katea[i] + "]");
                }

                // Validatu katearen luzera
                if (katea.length == 5) {
                    mezuak.add(new Mezua(katea[0], katea[1], katea[2], katea[3], katea[4]));
                    System.out.println("Mezua gehituta: " + katea[0] + " " + katea[1] + " " + katea[2] + " " + katea[3] + " " + katea[4]);
                } else {
                    System.out.println("formatu okerra");
                }
            }

            JOptionPane.showMessageDialog(null, "Memoriako mezuak kargatu dira", "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Memoriako mezuak ezin izan dira MEZUAK.TXT kargatu", "Errorea",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); 
        }
    }

    public static void gorde() {
        try (BufferedWriter bWr = new BufferedWriter(new FileWriter("src/Mezuak.txt", false))) { 
            for (Mezua mezu : mezuak) {
                bWr.write(mezu.toString());
                bWr.newLine();
            }
            JOptionPane.showMessageDialog(null, "Memoriako mezuak MEZUAK.TXT fitxategian gorde egin dira", "Zorionak!",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Memoriako mezuak ezin izan dira MEZUAK.TXT gorde", "Errorea",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void gehitu() {
        try {
            Ariketa7Añadir frame = new Ariketa7Añadir();
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void inprimatu() {
        try {
            Ariketa7Imprimir frame = new Ariketa7Imprimir(mezuak);
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(mezuak.size());
    }
}
