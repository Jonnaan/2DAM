package Ariketa1;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ariketa7Imprimir extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	String mezua = "";

	/**
	 * Create the frame.
	 */
	public Ariketa7Imprimir(ArrayList<Mezua> mezuak) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 11, 414, 205);
		contentPane.add(textArea);

		JButton btnOK = new JButton("Ok");
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Ariketa7 frame = new Ariketa7();
					frame.setVisible(true);
				} catch (Exception h) {
					h.printStackTrace();
				}
				dispose();
			}
		});
		btnOK.setBounds(335, 227, 89, 23);
		contentPane.add(btnOK);

		System.out.println(mezuak.size());
		for (Mezua mezu : mezuak) {
			System.out.println(mezuak.toString());
			
				System.out.println(mezu.toString());
				mezua = mezua  + mezu.toString() + "\n";
				System.out.println(mezua);
			

		}
		textArea.setText(mezua);

	}
}
