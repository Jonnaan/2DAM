package XPath;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class xpath {

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document xpathDoc = db.parse("ventas.xml");

            XPath xPath = XPathFactory.newInstance().newXPath();

            String kontsulta = "//ventas/venta[producto=//producto[@venta=//dpto[nombre='Carnicería']/@id]/@id]/cantidad";
            String kontsulta2 = "//producto[@venta=//dpto[nombre='Carnicería']/@id]/precio/text()\r\n";
            String kontsulta3 = "//producto[@id=//venta[cantidad = 3]/producto]/nombre/text()";
            String kontsulta4 = "//dpto[@id = //producto[nombre = \"Naranjas\"]/@venta]/responsable/text()";
            String kontsulta5 = "//dptos/dpto [@id = //productos/producto [@id = //ventas/venta[data = '2013/3/10']/producto]/@venta ]/responsable/text()";
            
            NodeList Cantidad = (NodeList) xPath.evaluate(kontsulta4, xpathDoc, XPathConstants.NODESET);

            for (int i = 0; i < Cantidad.getLength(); i++) {
                System.out.println(Cantidad.item(i).getTextContent());
               
            }
              
        } catch (Exception e) {
            e.printStackTrace();
        }
   }
}
