package Binario;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class gestorBinario extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JLabel lblEquipoVisitante;
	public JTextField textELocal;
	public JTextField textEVisitante;
	public JTextField textFGVisitante;
	public JTextField textGLocal;
	public JTextField textFecha;
	public JTextField textLugar;
	public String equipoLocal;
	public String equipoVisitante;
	public int golesLocal;
	public int golesVisitante;
	public String lugar;
	public String fecha;
	private JButton btnCargar;
	private JButton btnGuardar;
	public JTable table;
	private ArrayList<Partido> partidos = new ArrayList<Partido>();
	public static final String fitxero = "src/partidos.dat";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gestorBinario frame = new gestorBinario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public gestorBinario() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 629);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblELocal = new JLabel("Equipo Local");
		lblELocal.setBounds(27, 38, 83, 14);
		contentPane.add(lblELocal);

		textELocal = new JTextField();
		textELocal.setBounds(142, 35, 148, 20);
		contentPane.add(textELocal);
		textELocal.setColumns(10);

		lblEquipoVisitante = new JLabel("Equipo Visitante");
		lblEquipoVisitante.setBounds(27, 70, 83, 14);
		contentPane.add(lblEquipoVisitante);

		textEVisitante = new JTextField();
		textEVisitante.setColumns(10);
		textEVisitante.setBounds(142, 66, 148, 20);
		contentPane.add(textEVisitante);

		JLabel lblGolesLocal = new JLabel("Goles Local");
		lblGolesLocal.setBounds(27, 100, 59, 14);
		contentPane.add(lblGolesLocal);

		JLabel lblGVisitante = new JLabel("Goles Visitante");
		lblGVisitante.setBounds(27, 132, 83, 14);
		contentPane.add(lblGVisitante);

		textFGVisitante = new JTextField();
		textFGVisitante.setColumns(10);
		textFGVisitante.setBounds(142, 128, 148, 20);
		contentPane.add(textFGVisitante);

		textGLocal = new JTextField();
		textGLocal.setColumns(10);
		textGLocal.setBounds(142, 97, 148, 20);
		contentPane.add(textGLocal);

		JLabel lblLugar = new JLabel("Lugar");
		lblLugar.setBounds(27, 160, 59, 14);
		contentPane.add(lblLugar);

		JLabel lblFecha = new JLabel("Fecha");
		lblFecha.setBounds(27, 192, 83, 14);
		contentPane.add(lblFecha);

		textFecha = new JTextField();
		textFecha.setColumns(10);
		textFecha.setBounds(142, 188, 148, 20);
		contentPane.add(textFecha);

		textLugar = new JTextField();
		textLugar.setColumns(10);
		textLugar.setBounds(142, 157, 148, 20);
		contentPane.add(textLugar);

		JButton btnAñadir = new JButton("Añadir");
		btnAñadir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				equipoLocal = textELocal.getText();
				equipoVisitante = textEVisitante.getText();
				try {
				    golesLocal = Integer.parseInt(textGLocal.getText());
				    golesVisitante = Integer.parseInt(textFGVisitante.getText());
				} catch (NumberFormatException e1) {
				    mensajeJOption("Los goles deben ser un número válido.");
				    return; // Salir del método si ocurre un error de conversión
				}

				
				lugar = textLugar.getText();
				fecha = textFecha.getText();

				añadirPartidos(partidos, equipoLocal, equipoVisitante, golesLocal, golesVisitante, lugar, fecha);
			}
		});
		btnAñadir.setBounds(27, 227, 89, 23);
		contentPane.add(btnAñadir);

		btnCargar = new JButton("Cargar");
		btnCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cargarDat();
				actualizarTabla();
				for (Partido partido : partidos) {
					System.out.println(partido);
				}
			}
		});
		btnCargar.setBounds(152, 227, 89, 23);
		contentPane.add(btnCargar);

		btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				guardarDat();
				
			}
		});
		btnGuardar.setBounds(271, 227, 89, 23);
		contentPane.add(btnGuardar);

	
		table = new JTable();
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Equipo Local", "Equipo Visitante",
				"Goles Local", "Goles Visitante", "Lugar", "Fecha" }));

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(27, 307, 373, 182); 
		contentPane.add(scrollPane);

	}

	public ArrayList<Partido> añadirPartidos(ArrayList<Partido> partidos, String equipoLocal, String equipoVisitante,
			int golesLocal, int golesVisitante, String lugar, String fecha) {
		// Pattern para validar fechas en formato dd/MM/yyyy
		Pattern pattern = Pattern.compile("^\\d{2}/\\d{2}/\\d{4}$");

		// Validar los campos
		if (equipoLocal.length() > 20 || equipoLocal.length() < 1 || equipoVisitante.length() > 20
				|| equipoVisitante.length() < 1) {
			mensajeJOption("El nombre del equipo debe tener entre 1 y 20 caracteres.");
		} else if (golesLocal < 0 || golesLocal > 99 || golesVisitante < 0 || golesVisitante > 99) {
			mensajeJOption("Los goles deben ser un número entre 0 y 99.");
		} else if (lugar.length() > 20 || lugar.length() < 1) {
			mensajeJOption("El lugar no puede superar los 20 caracteres.");
		} else if (!pattern.matcher(fecha).matches()) {
			mensajeJOption("La fecha debe ser en formato dd/MM/yyyy.");
		} else {
			Partido partido = new Partido(equipoLocal, equipoVisitante, golesLocal, golesVisitante, lugar, fecha);
			mensajeJOption("Partido añadido correctamente.");
			partidos.add(partido);
			limpiarTXTField();
			actualizarTabla(); // Actualizar la tabla
		}
		return partidos;
	}

	public void mensajeJOption(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}

	public void limpiarTXTField() {
		textELocal.setText("");
		textEVisitante.setText("");
		textFGVisitante.setText("");
		textGLocal.setText("");
		textFecha.setText("");
		textLugar.setText("");
	}

	public void actualizarTabla() {
		DefaultTableModel model = (DefaultTableModel) table.getModel();

		// Limpiar la tabla
		model.setRowCount(0);

		// Añadir a la tabla desde el ArrayList de partidos
		for (Partido partido : partidos) {
			Object[] row = new Object[] { partido.getEquipoLocal(), partido.getEquipoVisitante(),
					partido.getGolesLocal(), partido.getGolesVisitante(), partido.getLugar(), partido.getFecha() };
			model.addRow(row);
		}
	}

	public void guardarDat() {
	    try {
	        ObjectOutputStream ficheroSalida = new ObjectOutputStream(new FileOutputStream(fitxero));
	        ficheroSalida.writeObject(partidos);
	        ficheroSalida.flush();
	        ficheroSalida.close();
	        mensajeJOption("Partidos guardados correctamente.");
	    } catch (FileNotFoundException fnfe) {
	        mensajeJOption("Error: El fichero no existe.");
	    } catch (IOException ioe) {
	        mensajeJOption("Error: Fallo en la escritura en el fichero.");
	    }
	}


	public void cargarDat() {
	    try {
	        ObjectInputStream ficheroEntrada = new ObjectInputStream(new FileInputStream(fitxero));
	        partidos = (ArrayList<Partido>) ficheroEntrada.readObject();
	        ficheroEntrada.close();
	        mensajeJOption("Partidos cargados correctamente.");
	        actualizarTabla();
	    } catch (FileNotFoundException fnfe) {
	        mensajeJOption("Error: El fichero no existe.");
	    } catch (IOException ioe) {
	        mensajeJOption("Error: Fallo en la carga del fichero.");
	    } catch (ClassNotFoundException e) {
	        mensajeJOption("Error: No se ha encontrado la clase.");
	    }
	}


}
