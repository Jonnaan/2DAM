package Ariketa1;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Ariketa1.*;

public class Ariketa7 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static BufferedReader br;
	private static BufferedWriter bw;
	public static ArrayList<String> mezuak;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ariketa7 frame = new Ariketa7();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ariketa7() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		crearFichero();

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnSalir.setBounds(335, 227, 89, 23);
		contentPane.add(btnSalir);

		JButton btnCargar = new JButton("Cargar mensaje");
		btnCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cargar();
			}
		});
		btnCargar.setBounds(10, 11, 150, 23);
		contentPane.add(btnCargar);

		JButton btnGuardar = new JButton("Guardar mensajes");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				guardar();
			}
		});
		btnGuardar.setBounds(274, 11, 150, 23);
		contentPane.add(btnGuardar);

		JButton btnAñadir = new JButton("Añadir mensajes");
		btnAñadir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				añadir();
				dispose();
			}
		});
		btnAñadir.setBounds(10, 45, 150, 23);
		contentPane.add(btnAñadir);

		JButton btnImprimir = new JButton("Imprimir mensajes");
		btnImprimir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (mezuak != null) {
					imprimir();
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "Error");
				}
			}
		});
		btnImprimir.setBounds(274, 45, 150, 23);
		contentPane.add(btnImprimir);
	}

	private static void crearFichero() {
		mezuak = new ArrayList<String>();
		if (br == null && bw == null) {
			// Si no existe el fichero lo crea
			try {
				bw = new BufferedWriter(new FileWriter("Mezuak.txt"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static void cargar() {
		try (BufferedReader lector = new BufferedReader(new FileReader("Mezuak.txt"))) {
			String linea;
			while ((linea = lector.readLine()) != null) {
				mezuak.add(linea);
			}
			JOptionPane.showMessageDialog(null, "Memoriako mezuak kargatu dira", "Errorea",
					JOptionPane.INFORMATION_MESSAGE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Memoriako mezuak ezin izan dira MEZUAK.TXT kargatu", "Errorea",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private static void guardar() {
		try (BufferedWriter escritor = new BufferedWriter(new FileWriter("Mezuak.txt"))) {
			for (String linea : mezuak) {
				escritor.write(linea + "//");
				System.out.println(linea);
			}
			JOptionPane.showMessageDialog(null, "Memoriako mezuak MEZUAK.TXT fitxategian gorde egin dira", "Zorionak!",
					JOptionPane.INFORMATION_MESSAGE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Memoriako mezuak ezin izan dira MEZUAK.TXT gorde", "Errorea",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private static void añadir() {
		try {
			Ariketa7Añadir frame = new Ariketa7Añadir();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void imprimir() {
		try {
			Ariketa7Imprimir frame = new Ariketa7Imprimir();
			frame.setVisible(true);
		} catch (Exception o) {
			o.printStackTrace();
		}
	}
}
