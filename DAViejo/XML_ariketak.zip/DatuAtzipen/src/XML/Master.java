package XML;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Master {

	public static void main(String[] args) {
		crearFicheroXML();
		leerFicheroXML();
		añadirNuevosDatos();
	}

	public static void crearFicheroXML() {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			DOMImplementation implent = builder.getDOMImplementation();

			Document doc = implent.createDocument(null, "Discos", null);
			doc.setXmlVersion("1.0");

			Element cd = doc.createElement("CD");
			Element titulo = doc.createElement("Titulo");
			Element artista = doc.createElement("Artista");
			Element pais = doc.createElement("Pais");
			Element sello = doc.createElement("Sello");
			Element precio = doc.createElement("Precio");
			Element año = doc.createElement("Año");

			titulo.setTextContent("Empire Burlesque");
			artista.setTextContent("Bob Dylan");
			pais.setTextContent("EE.UU.");
			sello.setTextContent("Columbia");
			precio.setTextContent("10.90");
			año.setTextContent("1985");

			cd.appendChild(titulo);
			cd.appendChild(artista);
			cd.appendChild(pais);
			cd.appendChild(sello);
			cd.appendChild(precio);
			cd.appendChild(año);

			doc.getDocumentElement().appendChild(cd);

			Source source = new DOMSource(doc);
			Result result = new StreamResult(new File("discos.xml"));

			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(source, result);

		} catch (ParserConfigurationException | TransformerException e) {
			Logger.getLogger(Master.class.getName()).log(Level.SEVERE, null, e);
		}
	}

	public static void leerFicheroXML() {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new File("discos.xml"));
			NodeList listaCDs = doc.getElementsByTagName("CD");

			for (int i = 0; i < listaCDs.getLength(); i++) {
				Node nodo = listaCDs.item(i);
				if (nodo.getNodeType() == Node.ELEMENT_NODE) {
					Element e = (Element) nodo;
					String titulo = e.getElementsByTagName("Titulo").item(0).getTextContent();
					String artista = e.getElementsByTagName("Artista").item(0).getTextContent();
					String pais = e.getElementsByTagName("Pais").item(0).getTextContent();
					String sello = e.getElementsByTagName("Sello").item(0).getTextContent();
					String precio = e.getElementsByTagName("Precio").item(0).getTextContent();
					String año = e.getElementsByTagName("Año").item(0).getTextContent();

					System.out.println("CD: " + (i + 1));
					System.out.println("  Titulo: " + titulo);
					System.out.println("  Artista: " + artista);
					System.out.println("  Pais: " + pais);
					System.out.println("  Sello: " + sello);
					System.out.println("  Precio: " + precio);
					System.out.println("  Año: " + año);
				}
			}
		} catch (Exception e) {
			Logger.getLogger(Master.class.getName()).log(Level.SEVERE, null, e);
		}

	}
	
	public static void añadirNuevosDatos() {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new File("discos.xml"));
			NodeList listaCDs = doc.getElementsByTagName("CD");

			Element cd = doc.createElement("CD");
			Element titulo = doc.createElement("Titulo");
			Element artista = doc.createElement("Artista");
			Element pais = doc.createElement("Pais");
			Element sello = doc.createElement("Sello");
			Element precio = doc.createElement("Precio");
			Element año = doc.createElement("Año");

			titulo.setTextContent("Another Side of Bob Dylan");
			artista.setTextContent("Bob Dylan");
			pais.setTextContent("EE.UU.");
			sello.setTextContent("Columbia");
			precio.setTextContent("7.90");
			año.setTextContent("1964");

			cd.appendChild(titulo);
			cd.appendChild(artista);
			cd.appendChild(pais);
			cd.appendChild(sello);
			cd.appendChild(precio);
			cd.appendChild(año);

			doc.getDocumentElement().appendChild(cd);

			Source source = new DOMSource(doc);
			Result result = new StreamResult(new File("discos.xml"));

			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(source, result);

		} catch (Exception e) {
			Logger.getLogger(Master.class.getName()).log(Level.SEVERE, null, e);
		}
	}

}
