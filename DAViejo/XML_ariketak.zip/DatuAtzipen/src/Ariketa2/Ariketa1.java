package Ariketa2;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Ariketa1 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldLocal;
	private JTextField textFielVisitor;
	private JTextField textFieldGolLocal;
	private JTextField textFieldGolVisitor;
	private JTextField textFieldLugar;
	private JTextField textFieldFecha;
	private JTable table;
	private ArrayList<Resultado> resultados = new ArrayList<Resultado>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ariketa1 frame = new Ariketa1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ariketa1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel lblTitulo = new JLabel("Liga");
		contentPane.add(lblTitulo, BorderLayout.NORTH);
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 25));
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane);
		
		JPanel panel = new JPanel();
		scrollPane.setRowHeaderView(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel lblLocal = new JLabel("Equipo local:");
		panel.add(lblLocal);
		
		JLabel lblVisitante = new JLabel("Equipo visitante:");
		panel.add(lblVisitante);
		
		JLabel lblGolLocal = new JLabel("Goles locales:");
		panel.add(lblGolLocal);
		
		JLabel lblGolVisitante = new JLabel("Goles visitantes:");
		panel.add(lblGolVisitante);
		
		JLabel lblLugar = new JLabel("Lugar:");
		panel.add(lblLugar);
		
		JLabel lblFecha = new JLabel("Fecha:");
		panel.add(lblFecha);
		
		JButton btnAñadir = new JButton("Añadir");
		btnAñadir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				añadir();
			}
		});
		panel.add(btnAñadir);
		
		JButton btnCargar = new JButton("Cargar");
		btnCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel.add(btnCargar);
		
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel.add(btnGuardar);
		
		JPanel panel_1 = new JPanel();
		scrollPane.setViewportView(panel_1);
		panel_1.setLayout(null);
		
		textFieldLocal = new JTextField();
		textFieldLocal.setBounds(10, 11, 437, 20);
		panel_1.add(textFieldLocal);
		textFieldLocal.setColumns(10);
		
		textFielVisitor = new JTextField();
		textFielVisitor.setColumns(10);
		textFielVisitor.setBounds(10, 53, 437, 20);
		panel_1.add(textFielVisitor);
		
		textFieldGolLocal = new JTextField();
		textFieldGolLocal.setColumns(10);
		textFieldGolLocal.setBounds(10, 94, 437, 20);
		panel_1.add(textFieldGolLocal);
		
		textFieldGolVisitor = new JTextField();
		textFieldGolVisitor.setColumns(10);
		textFieldGolVisitor.setBounds(10, 136, 437, 20);
		panel_1.add(textFieldGolVisitor);
		
		textFieldLugar = new JTextField();
		textFieldLugar.setColumns(10);
		textFieldLugar.setBounds(10, 172, 437, 20);
		panel_1.add(textFieldLugar);
		
		textFieldFecha = new JTextField();
		textFieldFecha.setColumns(10);
		textFieldFecha.setBounds(10, 215, 437, 20);
		panel_1.add(textFieldFecha);
		
		table = new JTable();
		table.setBounds(10, 259, 437, 98);
		panel_1.add(table);
	}
	
	private void añadir() {
		String local = textFieldLocal.getText();
        String visitor = textFielVisitor.getText();
        int golLocal = Integer.parseInt(textFieldGolLocal.getText());
        int golVisitor = Integer.parseInt(textFieldGolVisitor.getText());
        String lugar = textFieldLugar.getText();
        String fecha = textFieldFecha.getText();
        
        Resultado resultado = new Resultado(local, visitor, golLocal, golVisitor, lugar, fecha);
        resultados.add(resultado);
        System.out.println(resultados.toString());
        añadirTabla();
	}
	
	private void añadirTabla() {
		String[] columnas = { "Local", "Visitante", "Goles Local", "Goles Visitante", "Lugar", "Fecha" };
		String[][] datos = new String[resultados.size()][6];

		for (int i = 0; i < resultados.size(); i++) {
			datos[i][0] = resultados.get(i).getLocal();
			datos[i][1] = resultados.get(i).getVisitor();
			datos[i][2] = String.valueOf(resultados.get(i).getGolLocal());
			datos[i][3] = String.valueOf(resultados.get(i).getGolVisitor());
			datos[i][4] = resultados.get(i).getLugar();
			datos[i][5] = resultados.get(i).getFecha();
		}

		table = new JTable(datos, columnas);
	}
}
