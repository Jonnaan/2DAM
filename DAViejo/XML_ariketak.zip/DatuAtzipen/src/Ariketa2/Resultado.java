package Ariketa2;

public class Resultado {
	
	String local;
	String visitor;
	int golLocal;
	int golVisitor;
	String lugar;
	String fecha;
	
	public Resultado(String local, String visitor, int golLocal, int golVisitor, String lugar, String fecha) {
		this.local = local;
		this.visitor = visitor;
		this.golLocal = golLocal;
		this.golVisitor = golVisitor;
		this.lugar = lugar;
		this.fecha = fecha;
	}
	
	public String getLocal() {
		return local;
	}
	
	public String getVisitor() {
		return visitor;
	}
	
	public int getGolLocal() {
		return golLocal;
	}
	
	public int getGolVisitor() {
		return golVisitor;
	}		
	
	public String getLugar() {
		return lugar;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public void setLocal(String local) {
		this.local = local;
	}
	
	public void setVisitor(String visitor) {
		this.visitor = visitor;
	}
	
	public void setGolLocal(int golLocal) {
		this.golLocal = golLocal;
	}
	
	public void setGolVisitor(int golVisitor) {
		this.golVisitor = golVisitor;
	}
	
	public void setLugar(String lugar) {
		this.lugar = lugar;
	}
	
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	
	@Override
	public String toString() {
		return "Resultados [local=" + local + ", visitor=" + visitor + ", golLocal=" + golLocal + ", golVisitor="
				+ golVisitor + ", lugar=" + lugar + ", fecha=" + fecha + "]";
	}
	
	
	
}
